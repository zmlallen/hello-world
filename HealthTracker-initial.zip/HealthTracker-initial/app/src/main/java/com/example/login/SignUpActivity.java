package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignUpActivity extends AppCompatActivity {

    private EditText username;
    private EditText Password;
    private TextView forgetInfo, notMemberInfo;
    private Button SignIn, SignUp;
    private CheckBox RememberMe;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        username = (EditText) findViewById(R.id.etName);
        Password = (EditText) findViewById(R.id.etPassword);
        SignUp = (Button) findViewById(R.id.btCreate);
        mAuth = FirebaseAuth.getInstance();

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = username.getText().toString();
                String pwd = Password.getText().toString();

                if (userName.isEmpty()) {
                    username.setError("Please enter username");
                    username.requestFocus();
                } else if (pwd.isEmpty()) {
                    Password.setError("Please enter password");
                    Password.requestFocus();
                } else if (userName.isEmpty() && pwd.isEmpty()) {
                    Toast.makeText(SignUpActivity.this, "Fields Are Empty!", Toast.LENGTH_SHORT).show();

                } else if (!(userName.isEmpty() && pwd.isEmpty())) {
                    mAuth.createUserWithEmailAndPassword(userName, pwd)
                            .addOnCompleteListener(SignUpActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (!task.isSuccessful()) {
                                        Toast.makeText(SignUpActivity.this, "SignUp Unsuccessful!", Toast.LENGTH_SHORT).show();

                                    } else {
                                        Intent SignUpIntent = new Intent(SignUpActivity.this, LoggedIn.class);
                                        SignUpIntent.putExtra("username",username.getText().toString());
                                        startActivity(SignUpIntent);
                                    }
                                }
                            });
                } else {
                    Toast.makeText(SignUpActivity.this, "Error Occurred!", Toast.LENGTH_SHORT).show();
                }
            }
        });


        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if (mFirebaseUser != null) {
                    Toast.makeText(SignUpActivity.this, "You are logged in", Toast.LENGTH_SHORT).show();
                    Intent s = new Intent(SignUpActivity.this, LoggedIn.class);
                    startActivity(s);
                } else {
                    Toast.makeText(SignUpActivity.this, "You are not logged in", Toast.LENGTH_SHORT).show();
                }
            }
        };


    }
}