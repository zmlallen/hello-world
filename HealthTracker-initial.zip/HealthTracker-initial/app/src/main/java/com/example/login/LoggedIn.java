package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;


public class LoggedIn extends AppCompatActivity {
    protected TextView email,weight,height,name;
    protected Button confirm;
    protected String account;
    private DatabaseReference mDatabase;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_logged_in);

        email=(TextView) findViewById(R.id.etUserName);
        name=(TextView) findViewById(R.id.etName);
        weight=(TextView) findViewById(R.id.etWeight);
        height=(TextView) findViewById(R.id.etHeight);
        confirm = (Button) findViewById(R.id.btConfirm);
        account = getIntent().getStringExtra("username");
        email.setText("welcome " + getIntent().getStringExtra("username"));
        mDatabase = FirebaseDatabase.getInstance().getReference();

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String Name = name.getText().toString();
                String Weight = weight.getText().toString();
                String Height = height.getText().toString();
                if (Name.isEmpty()) {
                    name.setError("Please enter name");
                    name.requestFocus();
                } else if (Weight.isEmpty()) {
                    weight.setError("Please enter weight");
                    weight.requestFocus();
                }else if (Height.isEmpty()) {
                    height.setError("Please enter height");
                    height.requestFocus();
                } else if (Name.isEmpty() && Weight.isEmpty() && Height.isEmpty() ) {
                    Toast.makeText(LoggedIn.this, "Fields Are Empty!", Toast.LENGTH_SHORT).show();
                } else if (!(Name.isEmpty() && Weight.isEmpty() && Height.isEmpty())) {
                    User u = new User(getIntent().getStringExtra("username"),Name,Height,Weight);
                    u.setNewUser();
                    mDatabase.child("users").child(account.replace(".", ",")).setValue(u);
                    Intent s = new Intent(LoggedIn.this,HomeActivity.class);
                    s.putExtra("username",account);
                    startActivity(s);
                } else {
                    Toast.makeText(LoggedIn.this, "Error Occurred!", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}