package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class HomeActivity extends AppCompatActivity {

    private Button Profile,Pedometer;
    private ImageButton ibtCamera,ibProfile,SignOut;

    protected TextView name,height;
    protected EditText  weight,calories;
    private String account;
    private DatabaseReference mDatabase;
    User u;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        SignOut =  findViewById(R.id.abtLogout);
        Profile = (Button) findViewById(R.id.btUser);
        Pedometer = (Button)findViewById(R.id.btPedometer);
        ibtCamera = findViewById(R.id.imbCamera);
        ibProfile = findViewById(R.id.ibtPerson);

        name = (TextView)findViewById(R.id.txName);
        account = getIntent().getStringExtra("username");


        readData(new FirebaseCallback() {
            @Override
            public void onCallback(User n) {
                name.setText( n.getName());
                u=n;
            }
        },getIntent().getStringExtra("username").replace(".",","));



        SignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(HomeActivity.this,MainActivity.class);
                startActivity(s);
            }
        });


        ibProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(HomeActivity.this,MainActivity2.class);
                s.putExtra("username",getIntent().getStringExtra("username"));
                startActivity(s);
            }
        });

        Pedometer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(HomeActivity.this, PedometerActivity.class);
                startActivity(login);
            }
        });

        Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(HomeActivity.this,ProfileActivity.class);
                s.putExtra("username",getIntent().getStringExtra("username"));
                startActivity(s);
            }
        });

        ibtCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(HomeActivity.this,CameraActivity.class);
                s.putExtra("username",getIntent().getStringExtra("username"));
                startActivity(s);
            }
        });



    }

    private void readData(final FirebaseCallback firebaseCallback, String uid){
        DatabaseReference  mReference =FirebaseDatabase.getInstance().getReference();
        DatabaseReference uidRef = mReference.child("users");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User n = dataSnapshot.getValue(User.class);
                firebaseCallback.onCallback(n);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("error");
            }
        };
        uidRef.child(uid).addListenerForSingleValueEvent(eventListener);
    }



    public interface FirebaseCallback{
      void onCallback(User u);
    }

    public int transferDate(String d){
        String[] d1 = d.split("-");
        return Integer.parseInt(d1[0]);
    }



}

