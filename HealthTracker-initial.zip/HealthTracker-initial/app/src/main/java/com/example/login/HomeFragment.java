package com.example.login;

import android.os.Bundle;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link HomeFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class HomeFragment extends Fragment {
    private Button Profile,Submit,chart,SignOut,Csubmit,Cchart;
    protected TextView name,height;
    protected EditText weight,calories;
    private String account;
    User u;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public HomeFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment HomeFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static HomeFragment newInstance(String param1, String param2) {
        HomeFragment fragment = new HomeFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);


        Profile = (Button) rootView.findViewById(R.id.btUser);
        Submit = (Button) rootView.findViewById(R.id.btAddWeight);
        Csubmit =(Button) rootView.findViewById(R.id.btC);
        name = (TextView)rootView.findViewById(R.id.txName);
        height =(TextView)rootView.findViewById(R.id.txHeight);
        weight = (EditText)rootView.findViewById(R.id.edWeight);
        calories = (EditText)rootView.findViewById(R.id.edC);
        account = getActivity().getIntent().getStringExtra("username");



        readData(new HomeActivity.FirebaseCallback() {
            @Override
            public void onCallback(User n) {
                name.setText("Name:  " + n.getName());
                height.setText("Height:  "+ n.getHeight() + " cm");
                name.setTextSize(TypedValue.COMPLEX_UNIT_SP,23);
                height.setTextSize(TypedValue.COMPLEX_UNIT_SP,23);
                u=n;
            }
        },getActivity().getIntent().getStringExtra("username").replace(".",","));





        Csubmit.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           final String c = calories.getText().toString();
                                           if (c.isEmpty()) {
                                               calories.setError("Please enter calories");
                                               calories.requestFocus();
                                           } else {
                                               DatabaseReference  mReference = FirebaseDatabase.getInstance().getReference();
                                               mReference.child("users").child(account.replace(".",",")).addListenerForSingleValueEvent(new ValueEventListener() {
                                                   @Override
                                                   public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                       User u =dataSnapshot.getValue(User.class);
                                                       String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                                                       String n;
                                                       if(u.getInTakeCalories().containsKey(date)) {
                                                           n = Integer.toString(Integer.parseInt(u.getInTakeCalories().get(date)) + Integer.parseInt(c));
                                                       }else{
                                                           n=c;
                                                       }

                                                       Map<String, Object> hashMap = new HashMap<>();
                                                       hashMap.put( date, n);
                                                       dataSnapshot.child("inTakeCalories").getRef().updateChildren(hashMap);

                                                   }
                                                   @Override
                                                   public void onCancelled(@NonNull DatabaseError databaseError) {

                                                   }

                                               });

                                           }
                                           Toast.makeText(getActivity(), "Updated!", Toast.LENGTH_SHORT).show();
                                           calories.getText().clear();
                                       }

                                   }
        );


        Submit.setOnClickListener(new View.OnClickListener() {
                                      @Override
                                      public void onClick(View v) {
                                          final String newWeight = weight.getText().toString();
                                          if (newWeight.isEmpty()) {
                                              weight.setError("Please enter weight");
                                              weight.requestFocus();
                                          } else {
                                              DatabaseReference  mReference =FirebaseDatabase.getInstance().getReference();
                                              mReference.child("users").child(account.replace(".",",")).child("weight").addListenerForSingleValueEvent(new ValueEventListener() {
                                                  @Override
                                                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {

                                                      String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
                                                      Map<String, Object> hashMap = new HashMap<>();
                                                      hashMap.put( date, newWeight);
                                                      dataSnapshot.getRef().updateChildren(hashMap);

                                                  }
                                                  @Override
                                                  public void onCancelled(@NonNull DatabaseError databaseError) {

                                                  }

                                              });

                                          }
                                          Toast.makeText(getActivity(), "Updated!", Toast.LENGTH_SHORT).show();
                                          weight.getText().clear();
                                      }

                                  }
        );



        return rootView;
    }

    private void readData(final HomeActivity.FirebaseCallback firebaseCallback, String uid){
        DatabaseReference  mReference =FirebaseDatabase.getInstance().getReference();
        DatabaseReference uidRef = mReference.child("users");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User n = dataSnapshot.getValue(User.class);
                firebaseCallback.onCallback(n);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("error");
            }
        };
        uidRef.child(uid).addListenerForSingleValueEvent(eventListener);
    }



    public interface FirebaseCallback{
        void onCallback(User u);
    }

    public int transferDate(String d){
        String[] d1 = d.split("-");
        return Integer.parseInt(d1[0]);
    }



}