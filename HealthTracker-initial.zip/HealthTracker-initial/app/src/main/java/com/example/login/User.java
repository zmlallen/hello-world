package com.example.login;

import java.util.HashMap;
import java.util.Map;
import java.util.Date;
import java.text.SimpleDateFormat;
import java.util.TreeMap;

public class User {
    private String uid;
    private String name;
    private String height;
    private Map<String,String> weight;
    private Map<String,String> footSteps;
    private Map<String,String> inTakeCalories ;
    private boolean newUser;

    public User(){
        this.uid = "id";
        this.name = "name";
        this.height ="height";
        this.weight= new TreeMap<String,String>();
        this.footSteps= new TreeMap<String,String>();
        this.inTakeCalories= new TreeMap<String,String>();
        this.newUser=true;
    }

    public User(String id,String n, String h, String w) {
        this.uid = id;
        this.name =n;
        this.height =h;
        this.weight= new HashMap<String,String>();
        this.footSteps= new TreeMap<String,String>();
        this.inTakeCalories= new TreeMap<String,String>();
        String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        this.weight.put(date,w);
        this.footSteps.put(date,"0");
        this.inTakeCalories.put(date,"0");
        this.newUser=true;
    }

    public String getHeight() {
        return height;
    }

    public String getName() {
        return name;
    }

    public Map<String, String> getWeight() {
        return weight;
    }

    public Map<String, String> getInTakeCalories() {
        return inTakeCalories;
    }

    public Map<String, String> getFootSteps() {
        return footSteps;
    }

    public boolean isNewUser() {
        return newUser;
    }

    public void addNewWeight(String w){
        String date = new SimpleDateFormat("dd-MM-yyyy").format(new Date());
        this.weight.put(date,w);
    }

    public void setNewUser(){
        newUser = false;
    }


    public String read(){
        return "name:  "+name +"height: " + height;
    }

}
