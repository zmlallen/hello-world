package com.example.login;

import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

public class ProfileActivity extends AppCompatActivity {
    private String account,id;
    private LinearLayout linearLayout;
    private TextView textView;
    private EditText edtextd,edtextm,edtexty,edtext2;
    private int i;
    private ArrayList<EditText> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        account = getIntent().getStringExtra("username");

        readData(new HomeActivity.FirebaseCallback() {
            @Override
            public void onCallback(User n) {

                SortedSet<String> sSet = new TreeSet<>(new Comparator<String>() {
                    @Override
                    public int compare(String o1, String o2) {
                        String[] o11 = o1.split("-");
                        String[] o22 = o2.split("-");
                        if (Integer.parseInt(o11[0]) + Integer.parseInt(o11[1]) * 30 + Integer.parseInt(o11[2]) * 365 > Integer.parseInt(o22[0]) + Integer.parseInt(o22[1]) * 30 + Integer.parseInt(o22[2]) * 365) {
                            return 1;
                        } else if (Integer.parseInt(o11[0]) + Integer.parseInt(o11[1]) * 30 + Integer.parseInt(o11[2]) * 365 == Integer.parseInt(o22[0]) + Integer.parseInt(o22[1]) * 30 + Integer.parseInt(o22[2]) * 365) {
                            return 0;
                        } else {
                            return -1;
                        }
                    }
                });

                for (String s : n.getWeight().keySet()) {
                    sSet.add(s);
                }

                linearLayout = new LinearLayout(getApplicationContext());
                setContentView(linearLayout);
                linearLayout.setOrientation(LinearLayout.VERTICAL);
                linearLayout.setBackgroundColor(Color.WHITE);

                i=0;

                for(String s :sSet) {
                    id=s;
                    textView = new TextView(getApplicationContext());
                    textView.setText(s + "----" + n.getWeight().get(s) + "kg");
                    textView.setGravity(View.TEXT_ALIGNMENT_GRAVITY);
                    Button bt = new Button(getApplicationContext());
                    bt.setText("Delete");

                    bt.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            DatabaseReference ref = FirebaseDatabase.getInstance().getReference();
                            Query applesQuery = ref.child("users").child(account.replace(".",",")).child("weight").child(id);

                            applesQuery.addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(DataSnapshot dataSnapshot) {

                                    dataSnapshot.getRef().removeValue();
                                }

                                @Override
                                public void onCancelled(DatabaseError databaseError) {
                                    Log.e("TAG", "onCancelled", databaseError.toException());
                                }
                            });
                            linearLayout.removeView((View) textView.getParent());
                            finish();
                            startActivity(getIntent());
                        }
                    });


                    linearLayout.addView(textView);
                    linearLayout.addView(bt);

                }

                edtext2 = new EditText(getApplicationContext());
                edtext2.setHint("Enter the new weight");
                edtextd = new EditText(getApplicationContext());
                edtextd.setHint("Enter the date");
                edtextm = new EditText(getApplicationContext());
                edtextm.setHint("Enter the month");
                edtexty = new EditText(getApplicationContext());
                edtexty.setHint("Enter the year");
                edtext2.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
                edtextd.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
                edtextm.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
                edtexty.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
                linearLayout.addView(edtext2);
                linearLayout.addView(edtextd);
                linearLayout.addView(edtextm);
                linearLayout.addView(edtexty);
                Button button = new Button(getApplicationContext());
                button.setText("Add");
                button.setOnClickListener(new View.OnClickListener() {
                                              @Override
                                              public void onClick(View v) {
                                                  final String newWeight = edtext2.getText().toString();
                                                  final String date = edtextd.getText().toString();
                                                  final String month = edtextm.getText().toString();
                                                  final String year = edtexty.getText().toString();

                                                  if (newWeight.isEmpty()) {
                                                      edtext2.setError("Please enter weight");
                                                      edtext2.requestFocus();
                                                  }else if(date.isEmpty()){
                                                      edtextd.setError("Please enter Date");
                                                      edtextd.requestFocus();
                                                  }else if(month.isEmpty()){
                                                      edtextm.setError("Please enter Date");
                                                      edtextm.requestFocus();
                                                  }
                                                  else if(year.isEmpty()){
                                                      edtexty.setError("Please enter Date");
                                                      edtexty.requestFocus();
                                                  } else{
                                                      DatabaseReference  mReference =FirebaseDatabase.getInstance().getReference();
                                                      mReference.child("users").child(account.replace(".",",")).child("weight").addListenerForSingleValueEvent(new ValueEventListener() {
                                                          @Override
                                                          public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                                              String newDate = date + "-"+ month + "-" + year;
                                                              Map<String, Object> hashMap = new HashMap<>();
                                                              hashMap.put( newDate, newWeight);
                                                              dataSnapshot.getRef().updateChildren(hashMap);

                                                          }
                                                          @Override
                                                          public void onCancelled(@NonNull DatabaseError databaseError) {

                                                          }

                                                      });

                                                  }
                                                  Toast.makeText(ProfileActivity.this, "Updated!", Toast.LENGTH_SHORT).show();
                                                  finish();
                                                  startActivity(getIntent());
                                              }

                                          }
                );

                linearLayout.addView(button);

            }
        },getIntent().getStringExtra("username").replace(".",","));



    }

    private void readData(final HomeActivity.FirebaseCallback firebaseCallback, String uid){
        DatabaseReference mReference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference uidRef = mReference.child("users");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User n = dataSnapshot.getValue(User.class);
                firebaseCallback.onCallback(n);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("error");
            }
        };
        uidRef.child(uid).addListenerForSingleValueEvent(eventListener);
    }



    public interface FirebaseCallback{
        void onCallback(User u);
    }
}
