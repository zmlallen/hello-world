package com.example.login;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText Password;
    private Button SignIn, SignUp,Forget,Guest;
    private CheckBox RememberMe;
    FirebaseAuth mFirebaseAuth;
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = (EditText) findViewById(R.id.etName);
        Password = (EditText) findViewById(R.id.etPassword);
        Forget = (Button) findViewById(R.id.btForget);
        SignIn = (Button) findViewById(R.id.btSignIn);
        SignUp = (Button) findViewById(R.id.btSignUp);
        Guest = findViewById(R.id.btGuest);
        RememberMe = (CheckBox) findViewById(R.id.cbRememberMe);
        mAuth = FirebaseAuth.getInstance();

        SharedPreferences preferences= getSharedPreferences("checkbox",MODE_PRIVATE);
        String checkbox = preferences.getString("remember","");

        if(checkbox.equals("true")){
            RememberMe.setChecked(true);
            username.setText(preferences.getString("email",""));
            Password.setText(preferences.getString("password",""));
        }else{
            RememberMe.setChecked(false);
        }

        RememberMe.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton compoundButton,boolean b){
                if(compoundButton.isChecked()) {
                    SharedPreferences preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("remember","true");
                    editor.putString("password",Password.getText().toString());
                    editor.putString("email",username.getText().toString());
                    editor.apply();
                    Toast.makeText(MainActivity.this,"Checked",Toast.LENGTH_SHORT).show();

                }else if(!compoundButton.isChecked()){
                    SharedPreferences preferences=getSharedPreferences("checkbox",MODE_PRIVATE);
                    SharedPreferences.Editor editor=preferences.edit();
                    editor.putString("remember","false");
                    editor.apply();
                    Toast.makeText(MainActivity.this,"UnChecked",Toast.LENGTH_SHORT).show();

                }
            }
        });

        Guest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(MainActivity.this, GuestActivity.class);
                startActivity(login);
            }
        });

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent login = new Intent(MainActivity.this, SignUpActivity.class);
                startActivity(login);
            }
        });


        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser mFirebaseUser = mFirebaseAuth.getCurrentUser();
                if(mFirebaseUser != null){
                    Toast.makeText(MainActivity.this,"You are logged in",Toast.LENGTH_SHORT).show();
                    Intent s = new Intent(MainActivity.this,LoggedIn.class);
                    startActivity(s);
                }
                else{
                    Toast.makeText(MainActivity.this,"You are not logged in",Toast.LENGTH_SHORT).show();
                }
            }
        };


        SignIn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = username.getText().toString();
                String pwd = Password.getText().toString();

                if (userName.isEmpty()) {
                    username.setError("Please enter username");
                    username.requestFocus();
                } else if (pwd.isEmpty()) {
                    Password.setError("Please enter password");
                    Password.requestFocus();
                } else if (userName.isEmpty() && pwd.isEmpty() ) {
                    Toast.makeText(MainActivity.this, "Fields Are Empty!", Toast.LENGTH_SHORT).show();

                } else if (!(userName.isEmpty() && pwd.isEmpty())) {
                    mAuth.signInWithEmailAndPassword(userName,pwd).addOnCompleteListener(MainActivity.this, new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if(!task.isSuccessful()){
                                Toast.makeText(MainActivity.this, "Email address or password is wrong", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Log.d("MainActivity","signInWithEmail:success");
                                FirebaseUser user = mAuth.getCurrentUser();
                                readData(new HomeActivity.FirebaseCallback() {
                                    @Override
                                    public void onCallback(User n) {
                                        if(!n.isNewUser()){
                                            Intent s = new Intent(MainActivity.this,HomeActivity.class);
                                            s.putExtra("username",username.getText().toString());
                                            startActivity(s);
                                        }else{
                                            Intent login = new Intent(MainActivity.this,LoggedIn.class);
                                            login.putExtra("username","" + username.getText().toString());
                                            startActivity(login);
                                        }
                                    }
                                },username.getText().toString().replace(".", ","));
                            }
                        }
                    });
                } else {
                    Toast.makeText(MainActivity.this, "Error Occurred!", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Forget.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mAuth.sendPasswordResetEmail(username.getText().toString())
                        .addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Log.d("MainActivity", "Email sent.");
                                    Toast.makeText(MainActivity.this, "Email sent!", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        });
    }

    private void readData(final HomeActivity.FirebaseCallback firebaseCallback, String uid){
        DatabaseReference mReference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference uidRef = mReference.child("users");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User n = dataSnapshot.getValue(User.class);
                firebaseCallback.onCallback(n);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("error");
            }
        };
        uidRef.child(uid).addListenerForSingleValueEvent(eventListener);
    }


    public interface FirebaseCallback{
        void onCallback(User u);
    }

}

