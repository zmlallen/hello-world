package com.example.login;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

public class GuestActivity extends AppCompatActivity {
    private ImageButton ibtCamera;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guest);

        ibtCamera = findViewById(R.id.imbCamera);
        ibtCamera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent s = new Intent(GuestActivity.this,CameraActivity.class);
                s.putExtra("username",getIntent().getStringExtra("username"));
                startActivity(s);
            }
        });
    }
}