package com.example.login;

import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.fragment.app.Fragment;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.Description;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.SortedSet;
import java.util.TreeSet;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link ProfileFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ProfileFragment extends Fragment {

    private DatabaseReference mDatabase;
    private ArrayList<Double> weight = new ArrayList<>();
    private ArrayList<BarEntry> barEntries;
    private ArrayList<String> labelsNames;
    private BarChart chart;
    private String account;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public ProfileFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment ProfileFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static ProfileFragment newInstance(String param1, String param2) {
        ProfileFragment fragment = new ProfileFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);
        account = getActivity().getIntent().getStringExtra("username");

        chart = rootView.findViewById(R.id.CbarChart);

        readData(new HomeActivity.FirebaseCallback() {
            @Override
            public void onCallback(User n) {

                SortedSet<String> sSet = new TreeSet<>(new Comparator<String>() {
                    @Override
                    public int compare(String o1, String o2) {
                        String[] o11 = o1.split("-");
                        String[] o22 = o2.split("-");
                        if (Integer.parseInt(o11[0]) + Integer.parseInt(o11[1]) * 30 + Integer.parseInt(o11[2]) * 365 > Integer.parseInt(o22[0]) + Integer.parseInt(o22[1]) * 30 + Integer.parseInt(o22[2]) * 365) {
                            return 1;
                        } else if (Integer.parseInt(o11[0]) + Integer.parseInt(o11[1]) * 30 + Integer.parseInt(o11[2]) * 365 == Integer.parseInt(o22[0]) + Integer.parseInt(o22[1]) * 30 + Integer.parseInt(o22[2]) * 365) {
                            return 0;
                        } else {
                            return -1;
                        }
                    }
                });

                for (String s : n.getInTakeCalories().keySet()) {
                    sSet.add(s);
                }

                barEntries = new ArrayList<>();
                labelsNames = new ArrayList<>();
                int i=0;
                String currentDate = sSet.first();
                for(String s :sSet){
                    if(i!=0) {
                        while (!isNextDay(currentDate, s)) {
                            barEntries.add(new BarEntry(i, 0));
                            i++;
                            currentDate = getNextDay(currentDate);
                            labelsNames.add(currentDate);
                            Log.d("TAG",currentDate);
                        }
                    }
                    int weight = Integer.parseInt(n.getInTakeCalories().get(s));
                    barEntries.add(new BarEntry(i,weight));
                    i++;
                    labelsNames.add(s);
                    currentDate =s;
                }

                barEntries.add(new BarEntry(i,0));
                labelsNames.add(getNextDay(currentDate));

                BarDataSet barDataSet = new BarDataSet(barEntries,"daily InTakeCalories");
                barDataSet.setColors(ColorTemplate.COLORFUL_COLORS);
                Description description = new Description();
                description.setText("Date");
                chart.setDescription(description);
                BarData barData = new BarData(barDataSet);
                chart.setData(barData);

                XAxis xAxis=chart.getXAxis();
                xAxis.setValueFormatter(new IndexAxisValueFormatter(labelsNames));
                xAxis.setPosition(XAxis.XAxisPosition.TOP);
                xAxis.setDrawGridLines(false);
                xAxis.setDrawAxisLine(false);
                xAxis.setTextSize(12f);
                xAxis.setGranularity(1.0f);
                barDataSet.setValueTextSize(15f);

                chart.setVisibleXRangeMaximum(5);
                chart.animateY(1000);
                chart.invalidate();

            }
        },getActivity().getIntent().getStringExtra("username").replace(".",","));
        return rootView;
    }

    private void readData(final HomeActivity.FirebaseCallback firebaseCallback, String uid){
        DatabaseReference  mReference = FirebaseDatabase.getInstance().getReference();
        DatabaseReference uidRef = mReference.child("users");
        ValueEventListener eventListener = new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                User n = dataSnapshot.getValue(User.class);
                firebaseCallback.onCallback(n);
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                System.out.println("error");
            }
        };
        uidRef.child(uid).addListenerForSingleValueEvent(eventListener);
    }

    private boolean isNextDay (String d1, String d2){
        String[] sd1 = d1.split("-");
        String[] sd2 = d2.split("-");
        if(sd2[2].equals(sd2[2]) && sd1[1].equals(sd2[1])){
            if((Integer.parseInt(sd1[0]) +1 ==Integer.parseInt(sd2[0]))){
                return true;
            }
        }
        return false;
    }

    private String getNextDay (String d) {
        try {
            Date date = new SimpleDateFormat("dd-MM-yyyy").parse(d);
            Calendar cal = Calendar.getInstance();
            cal.setTime(date);
            cal.add(Calendar.DATE, 1); //minus number would decrement the days
            date = cal.getTime();
            String nd = new SimpleDateFormat("dd-MM-yyyy").format(date);
            return nd;
        }catch(ParseException e){
            return d;
        }
    }

}